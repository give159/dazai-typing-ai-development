#!/usr/bin/env python3
"""計画モードのゲート：提案 → 承認 → 実装 → ブロック → 報告 の状態を管理する。

コマンド:
  gate.py propose --docs DIR                 提案を登録（DRAFT の文書）
  gate.py approve --scope TASK-001,TASK-002 --by 承認者   承認（範囲を指定）
  gate.py start TASK-001                      承認範囲内なら開始（範囲外・未承認は拒否）
  gate.py done TASK-001 --evidence 文字列      完了（根拠を必ず添える）
  gate.py block TASK-001 --reason 事実         ブロック（エンジニアへの相談文を作る）
  gate.py report --out 報告.md                 ログから事実のみの報告を作る

状態は .plan/state.json、ログは .plan/log.md に残る。
"""
import argparse
import datetime as dt
import json
import os
import sys

STATE = '.plan/state.json'
LOG = '.plan/log.md'


def load():
    if os.path.exists(STATE):
        return json.load(open(STATE, encoding='utf-8'))
    return {'stage': 'NONE', 'docs': None, 'scope': [], 'approved_by': None, 'tasks': {}}


def save(s):
    os.makedirs('.plan', exist_ok=True)
    json.dump(s, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)


def log(msg):
    os.makedirs('.plan', exist_ok=True)
    stamp = dt.datetime.now().strftime('%Y-%m-%d %H:%M')
    if not os.path.exists(LOG):
        open(LOG, 'w', encoding='utf-8').write('# 計画モードのログ\n\n')
    open(LOG, 'a', encoding='utf-8').write(f'- {stamp}｜{msg}\n')


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('propose'); p.add_argument('--docs', required=True)
    p = sub.add_parser('approve'); p.add_argument('--scope', required=True); p.add_argument('--by', required=True)
    p = sub.add_parser('start'); p.add_argument('task')
    p = sub.add_parser('done'); p.add_argument('task'); p.add_argument('--evidence', required=True)
    p = sub.add_parser('block'); p.add_argument('task'); p.add_argument('--reason', required=True)
    p = sub.add_parser('report'); p.add_argument('--out', required=True)
    a = ap.parse_args()
    s = load()

    if a.cmd == 'propose':
        if not os.path.isdir(a.docs):
            print('提案のフォルダが見つかりません', file=sys.stderr); return 2
        tasks = {}
        impl = os.path.join(a.docs, '実装仕様書.md')
        if os.path.exists(impl):
            import re
            for m in re.finditer(r'^- (TASK-\d{3})', open(impl, encoding='utf-8').read(), re.M):
                tasks[m.group(1)] = '未着手'
        s.update({'stage': 'PROPOSED', 'docs': a.docs, 'scope': [], 'approved_by': None, 'tasks': tasks})
        save(s); log(f'提案を登録（タスク {len(tasks)} 件、DRAFT）')
        print(f'提案を登録：タスク {len(tasks)} 件。承認を得てから approve してください。')
        return 0

    if a.cmd == 'approve':
        if s['stage'] != 'PROPOSED':
            print('先に propose で提案を登録してください', file=sys.stderr); return 2
        scope = [x.strip() for x in a.scope.split(',') if x.strip()]
        unknown = [x for x in scope if x not in s['tasks']]
        if unknown:
            print(f'承認範囲に存在しないタスク：{unknown}', file=sys.stderr); return 2
        s.update({'stage': 'APPROVED', 'scope': scope, 'approved_by': a.by})
        save(s); log(f'承認（承認者：{a.by}）範囲：{", ".join(scope)}')
        print(f'承認：{len(scope)} 件。範囲外のタスクは実装しません。')
        return 0

    if a.cmd == 'start':
        if s['stage'] not in ('APPROVED', 'IMPLEMENTING'):
            print('承認されていません（propose → approve の後に開始）', file=sys.stderr); log(f'拒否（未承認）：{a.task}'); return 1
        if a.task not in s['scope']:
            print(f'{a.task} は承認範囲外です。承認を得てから開始してください', file=sys.stderr); log(f'拒否（範囲外）：{a.task}'); return 1
        if s['tasks'].get(a.task) == 'ブロック中':
            print(f'{a.task} はブロック中です。エンジニアの判断を待ってください', file=sys.stderr); return 1
        s['tasks'][a.task] = '実装中'; s['stage'] = 'IMPLEMENTING'
        save(s); log(f'開始：{a.task}')
        print(f'開始：{a.task}（テストを先に書き、赤を確認してから実装）')
        return 0

    if a.cmd == 'done':
        if s['tasks'].get(a.task) != '実装中':
            print(f'{a.task} は実装中ではありません', file=sys.stderr); return 1
        s['tasks'][a.task] = '完了'
        save(s); log(f'完了：{a.task}／根拠：{a.evidence}')
        print(f'完了：{a.task}')
        return 0

    if a.cmd == 'block':
        if a.task not in s['tasks']:
            print('存在しないタスク', file=sys.stderr); return 2
        s['tasks'][a.task] = 'ブロック中'
        save(s); log(f'ブロック：{a.task}／事実：{a.reason}')
        os.makedirs('.plan', exist_ok=True)
        esc = [f'# エンジニアへの相談：{a.task}', '', f'## 件名', f'{a.task} で作業が止まっています。',
               '', '## 事実', f'- {a.reason}', '', '## 試したこと', '- （本人が時系列で記入）', '',
               '## 判断を仰ぐこと', '- 選択肢と、それぞれの影響を記入', '', '## 添付', '- .plan/log.md の該当部分（秘密情報は伏せる）']
        open(f'.plan/escalation_{a.task}.md', 'w', encoding='utf-8').write('\n'.join(esc) + '\n')
        print(f'ブロック：{a.task}。相談文：.plan/escalation_{a.task}.md')
        return 0

    if a.cmd == 'report':
        counts = {}
        for v in s['tasks'].values():
            counts[v] = counts.get(v, 0) + 1
        lines = ['# 進捗報告（事実のみ）', '', f"段階：{s['stage']}　／　承認者：{s.get('approved_by') or '未承認'}", '',
                 '## タスクの状態']
        lines += [f'- {k}：{v}' for k, v in s['tasks'].items()] or ['- （タスクなし）']
        lines += ['', '## 件数', *[f'- {k}：{v} 件' for k, v in counts.items()], '',
                  '## 出典', '- 状態は .plan/state.json、経過は .plan/log.md に記録。', '',
                  '（推測を含む場合は、本文と分けて「推測（未確認）」と書く）']
        open(a.out, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
        print(f'報告：{a.out}')
        return 0


if __name__ == '__main__':
    sys.exit(main())
