#!/usr/bin/env python3
"""仕様（spec.md）を検査する。要件・受け入れ基準・タスク・テストのIDのつながり（トレーサビリティ）と、曖昧語を確認する。

使い方:
  python3 spec_lint.py spec.md
終了コード：0＝合格、1＝不合格（修正が必要）
"""
import re
import sys

AMBIG = ['適切', '速く', 'いい感じ', 'なんとか', '柔軟', '使いやすく', '適宜', 'できるだけ', 'など']


def main():
    text = open(sys.argv[1], encoding='utf-8').read()
    reqs = set(re.findall(r'^- (REQ-\d{3})', text, re.M))  # 定義された要件（参照だけのIDは含めない）
    accs = dict(re.findall(r'\b(ACC-\d{3})\b（対応：(REQ-\d{3})', text))
    accs.update({a: r for a, r in re.findall(r'\b(ACC-\d{3})\s*\[対応:\s*(REQ-\d{3})\]', text)})
    tasks = {}
    for m in re.finditer(r'\b(TASK-\d{3})\s*\[対応:\s*([^\]]+)\]\s*\[依存:\s*([^\]]*)\]', text):
        tasks[m.group(1)] = (re.findall(r'REQ-\d{3}', m.group(2)), re.findall(r'TASK-\d{3}', m.group(3)))
    tests = {}
    for m in re.finditer(r'\b(TEST-\d{3})\s*\[対象:\s*([^\]]+)\]', text):
        tests[m.group(1)] = re.findall(r'ACC-\d{3}', m.group(2))
    problems = []
    if not reqs:
        problems.append('要件（REQ-）が一つもない')
    for r in sorted(reqs):
        if r not in accs.values():
            problems.append(f'{r}：受け入れ基準（ACC）がない')
        if not any(r in v[0] for v in tasks.values()):
            problems.append(f'{r}：この要件を指すタスク（TASK）がない')
    for a, r in accs.items():
        if r not in reqs:
            problems.append(f'{a}：存在しない要件 {r} を指している')
        if not any(a in v for v in tests.values()):
            problems.append(f'{a}：この受け入れ基準を指すテスト（TEST）がない')
    for t, (rs, deps) in tasks.items():
        if not rs:
            problems.append(f'{t}：対応する要件がない')
        for d in deps:
            if d not in tasks:
                problems.append(f'{t}：依存先 {d} が存在しない')
    # 循環
    state = {}
    def dfs(n, stack):
        state[n] = 1
        for m in tasks.get(n, ([], []))[1]:
            if m in tasks:
                if state.get(m) == 1:
                    problems.append('依存の循環：' + ' → '.join(stack + [m]))
                elif state.get(m) is None:
                    dfs(m, stack + [m])
        state[n] = 2
    for n in tasks:
        if state.get(n) is None:
            dfs(n, [n])
    for t, aa in tests.items():
        for a in aa:
            if a not in accs:
                problems.append(f'{t}：存在しない受け入れ基準 {a} を指している')
    for w in AMBIG:
        for m in re.finditer(re.escape(w), text):
            line = text[:m.start()].count('\n') + 1
            problems.append(f'{line}行目：曖昧語「{w}」（数値・条件で書く）')
    print(f'要件 {len(reqs)}、受け入れ基準 {len(accs)}、タスク {len(tasks)}、テスト {len(tests)}')
    if problems:
        print(f'不合格：{len(problems)} 件')
        for p in problems:
            print('- ' + p)
        return 1
    print('合格：仕様のIDは追跡でき、曖昧語はありません')
    return 0


if __name__ == '__main__':
    sys.exit(main())
