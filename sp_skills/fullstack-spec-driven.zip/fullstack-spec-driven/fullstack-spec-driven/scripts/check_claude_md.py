#!/usr/bin/env python3
"""CLAUDE.md に、仕様駆動開発に必要な項目があるかを確認する。

使い方:
  python3 check_claude_md.py CLAUDE.md
"""
import re
import sys

REQUIRED = {
    '仕様の場所': r'仕様は|spec\.md',
    'テストコマンド': r'テストコマンド',
    '禁止事項': r'禁止事項',
    '完了の定義': r'完了の定義',
    '技術スタック': r'技術スタック',
}
SECRET = re.compile(r'(?i)(api[_-]?key|password|secret)\s*[:=]\s*\S{6,}')


def main():
    text = open(sys.argv[1], encoding='utf-8').read()
    missing = [k for k, p in REQUIRED.items() if not re.search(p, text)]
    secrets = bool(SECRET.search(text))
    if missing:
        print('不足：' + '、'.join(missing))
    if secrets:
        print('要確認：秘密情報らしき値が書かれています（削除してください）')
    if not missing and not secrets:
        print('合格：必要な項目がそろっています')
        return 0
    return 1


if __name__ == '__main__':
    sys.exit(main())
